//
// Bootstrap Datepicker
//
"use strict";var Datepicker=function(){var e=$(".datepicker");e.length&&e.each(function(){$(this).datepicker({disableTouchKeyboard:!0,autoclose:!1})})}();