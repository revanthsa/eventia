//
// Select2.js
//
"use strict";var Select2=function(){var t=$('[data-toggle="select"]');t.length&&t.each(function(){$(this).select2({})})}();